// Договор HUD Astrum между шейдером текста и сервером. Серверная сторона — Core-lib,
// net.astrum.core.lib.hud.HudGlyphs; описание с примерами — docs/hud/README.md.
//
// Весь HUD приходит одной строкой текста (имя боссбара или actionbar). Строка нулевой ширины:
// после каждого элемента перо возвращается пробелом назад, поэтому клиент ставит её ровно в
// центр, и шейдер знает, где она начинается.
//
// Полоса пера (x): весь HUD игрока сдвинут пробелами на k * HUD_X_STEP пикселей вправо.
//   k = 0 — обычный текст, его шейдер не трогает. k >= 1 — элемент HUD, L = k - 1:
//     угол экрана = L & 7, масштаб = SCALES[(L >> 3) & 7], прозрачность = OPACITIES[(L >> 6) & 7].
//   Сдвиг одинаков для всех элементов HUD одного игрока: это его настройки, а не данные элемента.
//   Дальняя полоса HUD — панель тиммейтов, которой не хватает сдвига по y в цвете (-128 ... 127):
//     элемент левее начала строки на HUD_FAR + C * HUD_FAR_STEP. Угол = C & 7, размер =
//     SCALES[(C >> 3) & 7], прозрачность = OPACITIES[(C >> 6) & 7], к dy добавляется грубый
//     сдвиг (((C >> 9) & 15) - 8) * HUD_FAR_Y_STEP. x сервер сдвинул на HUD_FAR_BIAS к середине
//     (у правых углов вправо, у левых влево), чтобы панель шириной до 500 помещалась в полшага.
//   L >= SIDEBAR_FLAG — элемент сайдбара (строки сайдбара начинаются у правого края экрана,
//     поэтому полоса считается от него): масштаб = SCALES[L & 7], эффект цвета = (L >> 3) & 3
//     (SIDEBAR_SHINE, SIDEBAR_FLOW, SIDEBAR_RAINBOW), строк в сайдбаре = (L >> 5) & 15.
//     Масштаб — вокруг правого края на середине сайдбара: её шейдер находит по числу строк так
//     же, как игра ставит сайдбар (низ на h / 2 + строки * 3, строка 9 пикселей, заголовок над
//     строками). Эффект свой у каждого элемента: заголовок может переливаться, а подписи — нет.
//   Дальняя полоса сайдбара — сайдбар, который игрок поставил слева или сдвинул по вертикали:
//     элемент левее правого края экрана на SIDEBAR_FAR + C * SIDEBAR_STEP (шаг меньше обычного,
//     поэтому кодов больше). Размер = SCALES[C & 7], эффект = (C >> 3) & 3, слева = (C >> 5) & 1,
//     сдвиг по y = ((C >> 6) & 63) - 32 шагов по SIDEBAR_Y_STEP. Масштаб — вокруг края экрана
//     на его середине; разницу с серединой самого сайдбара сервер уже добавил к сдвигу. Сервер
//     сдвигает x элемента на SIDEBAR_BIAS (у левого края — на минус SIDEBAR_BIAS), чтобы
//     элементы шириной до 400 пикселей помещались в полшага; слева строку он раскладывает
//     вправо от нуля, и x считается от левого края экрана.
//   L >= TOAST_FLAG — элемент уведомления (в той же строке, что HUD): угол = T & 7,
//     размер = SCALES[(T >> 3) & 7], место в стопке = (T >> 6) & 7, где T = L - TOAST_FLAG.
//     Элементы уведомления стоят относительно его левого верхнего угла; шейдер сам ставит
//     уведомление в угол экрана и в стопку (TOAST_*). Полоса таймера (режим TIMER) встаёт
//     к низу уведомления: в её цвете места для сдвига по y нет.
//   T >= TOAST_SHIFTED — уведомление, сдвинутое от угла по y к центру экрана: S = T - TOAST_SHIFTED,
//     угол = TOAST_CORNERS[S & 3], размер = SCALES[(S >> 2) & 7], место в стопке = (S >> 5) & 3,
//     сдвиг = ((S >> 7) & 15) * TOAST_SHIFT_STEP пикселей экрана (после масштаба). По x отступ
//     от угла сервер делает пером, поделив на размер.
//     Полосы доходят до 7,5 млн пикселей: пробелы шрифта astrum:hud_space — до 2^22.
//   Уведомление в движении (выезжает из-за края экрана со стороны своего угла и уезжает обратно)
//     — у его элементов G < 128: высота TOAST_DY[G & 3], вылет — бит 2, тик начала движения по
//     модулю 16 — (G >> 3) & 15; дальше шейдер ведёт его сам по GameTime. На месте — G = dy + 128.
//     Полоса таймера считает то же по своим тику начала и длительности.
//   Сдвиг по стопке (место сменилось: подвинуло новое или ушло то, что ближе к углу) — G от
//     TOAST_MOVE_FIRST: C = G - TOAST_MOVE_FIRST, пришло с места дальше от угла — C >= 56,
//     высота TOAST_DY[(C % 56) / 14], тик начала по модулю 14 — C % 14. Полоса таймера на это
//     время — заливка (FILL) с тем же кодом: глиф на 11 ниже строки, 14 — в коде.
//
// Полоса шрифта (y): ascent глифа сдвинут на m * HUD_Y_STEP пикселей вниз, m — режим.
//   1 IMAGE   картинка или текст. G = dy + 128, цвет = R5G6B5 из (R << 8 | B)
//   2 FILL    полоса, заполненная слева на R / 255. G = dy + 128, B = 0 — градиент, иначе цвет R3G3B2
//   3 ROTATE  картинка, повёрнутая на R / 256 оборота. G = dy + 128, B = цвет R3G3B2
//   4 TIMER   полоса-таймер на своём месте (сайдбар): RGB = старт (тик дня, 15 бит) << 9 | длительность / 2
//   5 SPIN    вращение на своём месте: R = градусов за тик
//   6 PANEL   подложка. G = dy + 128, (R << 8 | B) = цвет R4G4B4 << 4 | непрозрачность 0..15
// Без полосы пера (k = 0: меню, диалоги, чат) режимы 1, 2, 6 работают на своём месте: цвет и dy
// разбираются так же, без угла и размера. Так в диалоге рисуются подложки, полосы и картинки HUD.
// Голова игрока (объект player_head, текстура 64x64) в полосу шрифта не попадает: её узнаём по
// полосе пера, сдвиг по y — в G, как у IMAGE.
//
// Угол экрана: 0 левый верх, 1 верх, 2 правый верх, 3 лево, 4 право, 5 левый низ, 6 низ, 7 правый низ.
// Элемент встаёт в угол со своим смещением от начала строки (перо по x, dy по y), умноженным
// на масштаб. Тень у служебных компонентов выключается сервером ("shadow_color": 0).

const float HUD_X_STEP = 2048.0;
const float HUD_Y_STEP = 8192.0;

const int MODE_NONE = 0;
const int MODE_IMAGE = 1;
const int MODE_FILL = 2;
const int MODE_ROTATE = 3;
const int MODE_TIMER = 4;
const int MODE_SPIN = 5;
const int MODE_PANEL = 6;
// Не полосы, а признаки, которые шейдер ставит сам.
const int MODE_HEAD = 50;
const int MODE_SPRITE = 51;

const int SIDEBAR_FLAG = 512;
const float HUD_FAR = 2162688.0;
const float HUD_FAR_STEP = 512.0;
const float HUD_FAR_BIAS = 200.0;
const float HUD_FAR_Y_STEP = 96.0;
const int HUD_FAR_CODES = 8192;
const float SIDEBAR_FAR = 8192.0;
const float SIDEBAR_STEP = 512.0;
const float SIDEBAR_BIAS = 160.0;
const float SIDEBAR_Y_STEP = 4.0;
const int SIDEBAR_CODES = 4096;
// Для эффекта цвета x у левого края переводится в отсчёт от правого края панели (ширина до 170).
const float SIDEBAR_EFFECT_WIDTH = 170.0;
// Между полосами сайдбара (до 1023) и уведомлений — запас: полоса сайдбара считается от правого
// края, и на очень широком экране первая оценка может ошибиться на единицу.
const int TOAST_FLAG = 1088;
const float TOAST_WIDTH = 160.0;
const float TOAST_HEIGHT = 28.0;
const float TOAST_GAP = 4.0;
const float TOAST_MARGIN = 4.0;
const float TOAST_BAR_Y = 25.0;
const int TOAST_SHIFTED = 512;
const float TOAST_MOTION_TICKS = 6.0;
// Метка движения «из будущего» (часы клиента отстают): не начинать раньше времени.
const float TOAST_MOTION_EARLY = 14.0;
const float TOAST_DY[4] = float[4](0.0, 4.0, 9.0, 14.0);
const int TOAST_MOVE_FIRST = 143;
const float TOAST_MOVE_EARLY = 12.0;
// Насколько дальше края экрана прячется уведомление: отступ от угла бывает до 60.
const float TOAST_HIDE_EXTRA = 64.0;
const float TOAST_SHIFT_STEP = 4.0;
const vec2 TOAST_CORNERS[4] = vec2[4](vec2(0.0, 0.0), vec2(1.0, 0.0), vec2(0.0, 1.0), vec2(1.0, 1.0));
const int SIDEBAR_SHINE = 1;
const int SIDEBAR_FLOW = 2;
const int SIDEBAR_RAINBOW = 3;

const float SCALES[8] = float[8](0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 2.5);
const float OPACITIES[8] = float[8](1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3);
const vec2 ANCHORS[8] = vec2[8](
    vec2(0.0, 0.0), vec2(0.5, 0.0), vec2(1.0, 0.0),
    vec2(0.0, 0.5),                 vec2(1.0, 0.5),
    vec2(0.0, 1.0), vec2(0.5, 1.0), vec2(1.0, 1.0)
);

// Строка имени боссбара i рисуется на y = 3 + 19 * i, actionbar — на 72 пикселя выше низа экрана.
const float BOSSBAR_FIRST_LINE = 3.0;
const float BOSSBAR_LINE_STEP = 19.0;
const float ACTIONBAR_FROM_BOTTOM = 72.0;

// Анимированный глиф: картинка = строка-заголовок, кадры сверху вниз, строка-подвал.
// В углах заголовка и подвала маркер, рядом параметры (см. spriteAnimation в rendertype_text.vsh).
const ivec3 SPRITE_MARKER = ivec3(255, 0, 254);
const int SPRITE_BLEND = 1;
const int SPRITE_PINGPONG = 2;

const float TAU = 6.28318530718;
const float DAY_TICKS = 24000.0;

vec3 rgb332(int bits) {
    return vec3(float((bits >> 5) & 7) / 7.0, float((bits >> 2) & 7) / 7.0, float(bits & 3) / 3.0);
}

vec3 rgb565(int bits) {
    return vec3(float((bits >> 11) & 31) / 31.0, float((bits >> 5) & 63) / 63.0, float(bits & 31) / 31.0);
}

// PANEL: R4G4B4 и непрозрачность 0..15.
vec4 panelColor(int bits) {
    return vec4(float((bits >> 12) & 15), float((bits >> 8) & 15), float((bits >> 4) & 15), float(bits & 15)) / 15.0;
}

// Поворот оттенка вокруг серой оси: яркость почти не меняется.
vec3 hueShift(vec3 color, float angle) {
    const vec3 k = vec3(0.57735);
    float c = cos(angle);
    return color * c + cross(k, color) * sin(angle) + k * dot(k, color) * (1.0 - c);
}

// Эффект цвета элемента сайдбара. x — пиксели от правого края экрана (отрицательные),
// seconds — время. Считается по вершинам: на глифе в 5-6 пикселей этого достаточно.
vec3 sidebarEffect(int effect, vec3 color, float x, float seconds) {
    if (effect == SIDEBAR_SHINE) {
        // Блик пробегает справа налево раз в 3 секунды.
        float center = 40.0 - fract(seconds / 3.0) * 280.0;
        float glow = clamp(1.0 - abs(x - center) / 14.0, 0.0, 1.0);
        return mix(color, vec3(1.0), 0.8 * glow);
    }
    if (effect == SIDEBAR_FLOW) {
        // Оттенок волной гуляет вокруг своего: градиент переливается.
        return clamp(hueShift(color, 0.7 * sin(x * 0.05 + seconds * 2.5)), 0.0, 1.0);
    }
    if (effect == SIDEBAR_RAINBOW) {
        float value = max(max(color.r, color.g), color.b);
        vec3 hue = clamp(abs(fract(x / 160.0 + seconds * 0.25 + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
        return value * mix(vec3(1.0), hue, 0.75);
    }
    return color;
}

// Насколько уведомление на месте: 0 — за краем экрана, 1 — на месте (с плавным разгоном).
float toastEase(float shown) {
    float rest = 1.0 - clamp(shown, 0.0, 1.0);
    return 1.0 - rest * rest * rest;
}

// Тиков прошло с метки start (тик дня) — с учётом перехода через полночь. Метка чуть из
// будущего (часы клиента отстают от сервера на пару тиков) значит «ещё не началось».
float ticksSince(float start, float now) {
    float elapsed = mod(now - start + DAY_TICKS, DAY_TICKS);
    return elapsed > DAY_TICKS - 200.0 ? 0.0 : elapsed;
}

// Элемент на дальней полосе сайдбара: так далеко левее экрана обычный текст не бывает. Ещё
// дальше — дальняя полоса HUD (она считается от начала строки HUD, isHudFar).
bool isSidebarFar(vec3 pos, vec2 screen) {
    float far = screen.x - pos.x - SIDEBAR_FAR;
    return far > -SIDEBAR_STEP * 0.5 && far < float(SIDEBAR_CODES) * SIDEBAR_STEP;
}

// Элемент на дальней полосе HUD; origin — начало строки HUD.
bool isHudFar(vec3 pos, vec2 origin) {
    float far = origin.x - pos.x - HUD_FAR;
    return far > -HUD_FAR_STEP * 0.5 && far < float(HUD_FAR_CODES) * HUD_FAR_STEP;
}

// Элемент сайдбара на полосе пера (L >= SIDEBAR_FLAG или дальняя полоса): вернуть на место,
// масштабировать, применить эффект цвета. false — это не элемент сайдбара.
// Тот же разбор и в rendertype_text_intensity.vsh: текст TTF-шрифтов (Retro Pixel) рисуется им.
bool sidebarElement(inout vec3 pos, inout vec4 color, vec2 screen) {
    if (isSidebarFar(pos, screen)) {
        float far = screen.x - pos.x - SIDEBAR_FAR;
        int code = int(floor(far / SIDEBAR_STEP + 0.5));
        if (code < 0 || code >= SIDEBAR_CODES) {
            return false;
        }
        bool left = ((code >> 5) & 1) == 1;
        // x от начала строки, как у сайдбара справа: строка начинается у правого края экрана.
        float x = float(code) * SIDEBAR_STEP - far - (left ? -SIDEBAR_BIAS : SIDEBAR_BIAS);
        color.rgb = sidebarEffect((code >> 3) & 3, color.rgb, left ? x - SIDEBAR_EFFECT_WIDTH : x,
                GameTime * DAY_TICKS / 20.0);
        float scale = SCALES[code & 7];
        float middle = floor(screen.y * 0.5);
        pos.x = (left ? 0.0 : screen.x) + x * scale;
        pos.y = middle + (pos.y - middle) * scale + float(((code >> 6) & 63) - 32) * SIDEBAR_Y_STEP;
        return true;
    }
    int band = int(floor((pos.x - screen.x) / HUD_X_STEP + 0.5));
    int settings = band - 1 - SIDEBAR_FLAG;
    if (settings < 0 || settings >= SIDEBAR_FLAG) {
        return false;
    }
    pos.x -= float(band) * HUD_X_STEP;
    color.rgb = sidebarEffect((settings >> 3) & 3, color.rgb, pos.x - screen.x, GameTime * DAY_TICKS / 20.0);
    float lines = float((settings >> 5) & 15);
    float bottom = floor(screen.y * 0.5) + lines * 3.0;
    vec2 anchor = vec2(screen.x, bottom - (lines + 1.0) * 4.5);
    pos.xy = anchor + (pos.xy - anchor) * SCALES[settings & 7];
    return true;
}
