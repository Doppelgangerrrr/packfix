#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;

// Админские пушки (Core-lib, net.astrum.core.lib.action.gun.GunViewmodel). Display-сущность,
// сдвинутая далеко вниз, — не часть мира:
//  ниже -6000 — оверлей экрана (прицел, маркер попадания, полоса перезарядки, цифры урона): x и z
//    после сдвига, умноженные на SCREEN_SCALE, — координаты экрана, где ±1 по z — его высота, а x
//    поправлен на соотношение сторон. Высота экрана идёт по z, а не по y: от первого лица display
//    стоит над глазами ровно по x и z, а по y его относит от камеры — присел, и точка посадки
//    опустилась сразу, а камера доезжает до глаз за несколько тиков; по y оверлей на это время
//    проваливался. В y остаётся только этот относ. От третьего лица камера отъезжает на блоки — по y
//    дальше SCREEN_REACH или по x, z дальше SCREEN_SIDE (сам оверлей вчетверо мельче, в пределах
//    блока) оверлей гасим: иначе сдвинутая оптика оставляла на экране кусок чёрных полей;
//  ниже -4000 — тот же оверлей прежних сборок Core-lib, высота экрана по y;
//  ниже -2000 — вьюмодель: координаты после сдвига — пространство взгляда, без поворота камеры,
//    поэтому модель прилипает к экрану.
const float VIEWMODEL_DEPTH = -2000.0;
const float VIEWMODEL_SHIFT = 2100.0;
const float OVERLAY_DEPTH = -4000.0;
const float OVERLAY_SHIFT = 4100.0;
const float SCREEN_DEPTH = -6000.0;
const float SCREEN_SHIFT = 6100.0;
const float SCREEN_REACH = 1.0;
const float SCREEN_SIDE = 1.2;
const float SCREEN_SCALE = 4.0;
// Дальше от камеры вьюмодель не бывает: от первого лица display стоит в глазах, и после сдвига
// остаются только координаты костей (самая длинная пушка — миниган, около 2 блоков). От третьего
// лица к ним добавляется отъезд камеры (4 блока) — тогда вьюмодель гасим прозрачностью, иначе у
// тела висела бы чужая. Именно гасим, а не уводим вершины за экран: треугольник, у которого
// увели только часть вершин, тянулся бы полосой через весь экран (стволы минигана).
const float VIEWMODEL_REACH = 2.3;
const float VIEWMODEL_FADE = 0.4;
// Вьюмодель — с полем зрения 70 при любом FOV и зуме, как ванильная рука (и пушки JEG): иначе на 110
// пушка вдвое мельче и в кадр с краю влезает рукав, а зум прицела её раздувал. 1/tan(35°).
const float VIEWMODEL_FOCAL = 1.4281480;

// Ближняя плоскость в координатах отсечения (z/w): -1 в OpenGL по умолчанию, 0 — в 26.x, где игра
// включает glClipControl(ZERO_TO_ONE). Берётся из самой проекции: ближняя плоскость игры — 0.05 блока.
float astrum_near_ndc() {
    return (ProjMat[3][2] - 0.05 * ProjMat[2][2]) / 0.05;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;

    if (Position.y < SCREEN_DEPTH) {
        vec3 screen = Position + vec3(0.0, SCREEN_SHIFT, 0.0);
        float aspect = ProjMat[1][1] / ProjMat[0][0];
        // Ближе всего, что есть в кадре: поверх мира и вьюмодели.
        float near = astrum_near_ndc();
        gl_Position = vec4(screen.x * SCREEN_SCALE / aspect, screen.z * SCREEN_SCALE, near + 0.0001 * (1.0 - near), 1.0);
        vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
        vertexColor.a *= 1.0 - max(step(SCREEN_REACH, abs(screen.y)), step(SCREEN_SIDE, length(screen.xz)));
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
    } else if (Position.y < OVERLAY_DEPTH) {
        vec3 screen = Position + vec3(0.0, OVERLAY_SHIFT, 0.0);
        float aspect = ProjMat[1][1] / ProjMat[0][0];
        // Ближе всего, что есть в кадре: поверх мира и вьюмодели.
        float near = astrum_near_ndc();
        gl_Position = vec4(screen.x / aspect, screen.y, near + 0.0001 * (1.0 - near), 1.0);
        vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
    } else if (Position.y < VIEWMODEL_DEPTH) {
        vec3 view = Position + vec3(0.0, VIEWMODEL_SHIFT, 0.0);
        vertexColor.a *= 1.0 - smoothstep(VIEWMODEL_REACH, VIEWMODEL_REACH + VIEWMODEL_FADE, length(view));
        // Дыхание: медленное покачивание считается здесь, по кадрам, и не стоит ни одного пакета.
        float ticks = GameTime * 24000.0;
        view.y += sin(ticks * 0.07) * 0.0028;
        view.x += sin(ticks * 0.035 + 1.3) * 0.0018;
        gl_Position = ProjMat * vec4(view, 1.0);
        // В ProjMat вшито покачивание камеры (поворот), поэтому фокус — длина строки y, а не ProjMat[1][1].
        float focal = length(vec3(ProjMat[0][1], ProjMat[1][1], ProjMat[2][1]));
        gl_Position.xy *= VIEWMODEL_FOCAL / focal;
        // Глубина сжата в самый ближний процент: модель поверх мира и не утыкается в стены. Ближняя
        // плоскость отсечения остаётся на месте — приклад у самой камеры обрезается, а не
        // раздувается на весь экран.
        float near = astrum_near_ndc() * gl_Position.w;
        gl_Position.z = near + (gl_Position.z - near) * 0.01;
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
    }
}
