#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;

// Ванильная подложка сайдбара — прямоугольники чёрного цвета с прозрачностью 0.3 (строки) и
// 0.4 (заголовок). Сайдбар Astrum шлёт строки нулевой ширины и рисует свою панель глифами;
// тогда подложка сжимается в полоску 2 пикселя у правого края — её и убираем, сдвигая вершины
// к краю экрана. У обычного сайдбара сдвигаются только правые вершины: фон дотягивается до
// края экрана на 3 пикселя, и больше ничего не меняется.
bool isSidebarEdge(vec2 screen) {
    ivec4 color = ivec4(round(Color * 255.0));
    bool sidebarColor = color.rgb == ivec3(0) && (color.a == 76 || color.a == 102);
    return sidebarColor && ProjMat[3][3] == 1.0 && Position.x >= screen.x - 8.0;
}

void main() {
    vec3 pos = Position;
    vec2 screen = vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]);
    if (isSidebarEdge(screen)) {
        pos.x = screen.x;
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    vertexColor = Color;
}
