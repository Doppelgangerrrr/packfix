#version 330

// Ваниль 1.21.11 как есть. Пак кладёт пару целиком: с одним нашим .vsh игра взяла бы .fsh из
// пака игрока ниже (свои шейдеры предметов, светящиеся руды и т. п.), а его входы наш .vsh не
// пишет — предметы рисовались чёрными.

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
