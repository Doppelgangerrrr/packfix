#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:astrum_hud.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

flat in int hudMode;
flat in vec4 hudData;
in vec2 hudLocal;
flat in vec2 hudNextFrame;
flat in float hudBlend;

out vec4 fragColor;

// Картинка глифа, повёрнутая на angle вокруг центра. Где глиф лежит в атласе, восстанавливаем
// по производным UV: внутри квада они линейны.
vec4 rotatedSample(float angle) {
    vec2 span = vec2(dFdx(texCoord0.x) / dFdx(hudLocal.x), dFdy(texCoord0.y) / dFdy(hudLocal.y));
    vec2 origin = texCoord0 - hudLocal * span;
    vec2 p = mat2(cos(angle), -sin(angle), sin(angle), cos(angle)) * (hudLocal - 0.5) + 0.5;
    if (any(lessThan(p, vec2(0.0))) || any(greaterThan(p, vec2(1.0)))) {
        return vec4(0.0);
    }
    return texture(Sampler0, origin + p * span);
}

// Красный -> жёлтый -> зелёный по доле заполнения.
vec3 healthColor(float fill) {
    vec3 low = vec3(1.0, 0.27, 0.22);
    vec3 mid = vec3(1.0, 0.82, 0.25);
    vec3 high = vec3(0.35, 0.95, 0.42);
    return fill < 0.5 ? mix(low, mid, fill * 2.0) : mix(mid, high, fill * 2.0 - 1.0);
}

void main() {
    vec4 sampled;
    if (hudMode == MODE_ROTATE) {
        sampled = rotatedSample(hudData.x * TAU);
    } else if (hudMode == MODE_SPIN) {
        sampled = rotatedSample(GameTime * DAY_TICKS * radians(hudData.x));
    } else {
        sampled = texture(Sampler0, texCoord0);
        if (hudBlend > 0.0) {
            sampled = mix(sampled, texture(Sampler0, texCoord0 + hudNextFrame), hudBlend);
        }
    }
    vec4 color = sampled * vertexColor * ColorModulator;

    if (hudMode == MODE_FILL) {
        float fill = hudData.x;
        if (hudLocal.x > fill) {
            // Пустая часть — та же картинка, тёмная и полупрозрачная.
            color.rgb *= 0.28;
            color.a *= 0.55;
        } else if (hudData.y < 0.5) {
            color.rgb *= healthColor(fill);
            if (fill < 0.3) {
                // Мало здоровья: полоса пульсирует сама, без пакетов с сервера.
                color.rgb = mix(color.rgb, vec3(1.0), 0.4 * (0.5 + 0.5 * sin(GameTime * DAY_TICKS * 0.6)));
            }
        }
    } else if (hudMode == MODE_TIMER) {
        // Таймер течёт на клиенте по кадрам: от полной полосы к пустой за длительность.
        float left = clamp(1.0 - ticksSince(hudData.x, GameTime * DAY_TICKS) / max(hudData.y, 1.0), 0.0, 1.0);
        if (hudLocal.x > left) {
            color.rgb *= 0.28;
            color.a *= 0.55;
        }
    }

    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
