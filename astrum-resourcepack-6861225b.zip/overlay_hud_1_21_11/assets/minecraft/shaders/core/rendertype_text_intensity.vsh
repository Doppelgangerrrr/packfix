#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:astrum_hud.glsl>

// Текст TTF-шрифтов (у них картинки глифов одноканальные) как в ванили, плюс полоса пера
// сайдбара Astrum: шрифт сети Retro Pixel рисуется этим шейдером, а не rendertype_text, и без
// разбора полосы текст сайдбара остался бы за краем экрана (include/astrum_hud.glsl).

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    if (ProjMat[3][3] == 1.0) {
        sidebarElement(pos, vertexColor, vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]));
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    texCoord0 = UV0;
}
