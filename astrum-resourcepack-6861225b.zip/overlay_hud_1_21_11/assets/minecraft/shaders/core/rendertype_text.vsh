#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:astrum_hud.glsl>

// Текст как в ванили, плюс HUD Astrum (договор — include/astrum_hud.glsl). Мир не трогается:
// все режимы работают только в интерфейсе.

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

flat out int hudMode;
flat out vec4 hudData;
// Угол квада 0..1: по нему заполняются полосы и поворачиваются картинки.
out vec2 hudLocal;
// Покадровые глифы: сдвиг UV до следующего кадра и доля перехода к нему.
flat out vec2 hudNextFrame;
flat out float hudBlend;

// Угол квада глифа (0 — левый или верхний край, 1 — правый или нижний) — по UV, а не по номеру
// вершины: игра сдвигает UV глифа внутрь на 0.01 текселя, поэтому у левого и верхнего края дробная
// часть UV в текселях 0.01, у правого и нижнего — 0.99. Номер вершины ненадёжен: в 26.2 интерфейс
// рисует партиями, и gl_VertexID % 4 в сайдбаре указывал не на тот угол.
vec2 cornerOf() {
    return step(vec2(0.5), fract(UV0 * vec2(textureSize(Sampler0, 0))));
}

// Глиф с заголовком анимации в картинке: кадры сверху вниз, в углах первой и последней строки
// маркер, рядом параметры (пиксель 1: кадров, высота кадра, тиков на кадр; пиксель 2: флаги).
// Каждая вершина читает свой угол картинки, поэтому заголовок продублирован и внизу.
bool spriteAnimation(inout vec3 pos) {
    ivec2 atlas = textureSize(Sampler0, 0);
    vec2 corner = cornerOf();
    // Пиксель угла картинки, в котором стоит вершина: UV сдвинуты внутрь, floor попадает в него.
    ivec2 texel = ivec2(floor(UV0 * vec2(atlas)));
    int inward = corner.x > 0.5 ? -1 : 1;

    ivec3 marker = ivec3(round(texelFetch(Sampler0, texel, 0).rgb * 255.0));
    if (marker != SPRITE_MARKER) {
        return false;
    }
    ivec3 params = ivec3(round(texelFetch(Sampler0, texel + ivec2(inward, 0), 0).rgb * 255.0));
    ivec3 flags = ivec3(round(texelFetch(Sampler0, texel + ivec2(inward * 2, 0), 0).rgb * 255.0));
    int frames = max(params.r, 1);
    float frameHeight = float(max(params.g, 1));
    float imageHeight = 2.0 + float(frames) * frameHeight;

    float ticks = GameTime * DAY_TICKS / float(max(params.b, 1));
    int step = int(floor(ticks));
    int frame = step % frames;
    int next = (step + 1) % frames;
    if ((flags.r & SPRITE_PINGPONG) != 0 && frames > 1) {
        int period = 2 * frames - 2;
        int phase = step % period;
        int nextPhase = (step + 1) % period;
        frame = phase < frames ? phase : period - phase;
        next = nextPhase < frames ? nextPhase : period - nextPhase;
    }

    float texelHeight = 1.0 / float(atlas.y);
    float top = UV0.y - corner.y * imageHeight * texelHeight;
    texCoord0.y = top + (1.0 + (float(frame) + corner.y) * frameHeight) * texelHeight;
    hudNextFrame = vec2(0.0, float(next - frame) * frameHeight * texelHeight);
    hudBlend = (flags.r & SPRITE_BLEND) != 0 ? fract(ticks) : 0.0;
    // На экране остаётся один кадр: нижние вершины поднимаются к низу первого кадра.
    pos.y -= corner.y * (imageHeight - frameHeight);
    return true;
}

void main() {
    vec3 pos = Position;
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    hudMode = MODE_NONE;
    hudData = vec4(0.0);
    hudLocal = vec2(0.0);
    hudNextFrame = vec2(0.0);
    hudBlend = 0.0;

    bool gui = ProjMat[3][3] == 1.0;
    if (gui) {
        vec2 screen = vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]);
        ivec3 rgb = ivec3(round(Color.rgb * 255.0));

        if (spriteAnimation(pos)) {
            hudMode = MODE_SPRITE;
        }

        // Полоса шрифта: режим.
        int mode = MODE_NONE;
        if (pos.y > HUD_Y_STEP * 0.5) {
            mode = int(floor(pos.y / HUD_Y_STEP + 0.5));
            pos.y -= float(mode) * HUD_Y_STEP;
        }

        // Откуда начинается строка: верхняя треть экрана — имена боссбаров, ниже — actionbar.
        vec2 origin;
        if (pos.y < screen.y / 3.0) {
            // Глифы строки лежат от 3 пикселей выше её верха (accented.png) до 15 ниже.
            float slot = floor((pos.y - BOSSBAR_FIRST_LINE + 3.0) / BOSSBAR_LINE_STEP);
            origin = vec2(floor(screen.x * 0.5), BOSSBAR_FIRST_LINE + BOSSBAR_LINE_STEP * slot);
        } else {
            origin = vec2(screen.x * 0.5, screen.y - ACTIONBAR_FROM_BOTTOM);
        }

        // Полоса пера: настройки HUD игрока.
        int band = int(floor((pos.x - origin.x) / HUD_X_STEP + 0.5));
        bool hudFar = isHudFar(pos, origin);
        bool head = textureSize(Sampler0, 0) == ivec2(64) && mode == MODE_NONE;

        if (band - 1 >= TOAST_FLAG) {
            // Уведомление: угол, размер, место в стопке и сдвиг от угла по y — в полосе пера.
            int settings = band - 1 - TOAST_FLAG;
            vec2 anchor = ANCHORS[settings & 7];
            float scale = SCALES[(settings >> 3) & 7];
            float slot = float((settings >> 6) & 7);
            float shift = 0.0;
            if (settings >= TOAST_SHIFTED) {
                int code = settings - TOAST_SHIFTED;
                anchor = TOAST_CORNERS[code & 3];
                scale = SCALES[(code >> 2) & 7];
                slot = float((code >> 5) & 3);
                shift = float((code >> 7) & 15) * TOAST_SHIFT_STEP;
            }
            // Высота элемента, насколько уведомление на месте (влетает, улетает или стоит) и сдвиг
            // по стопке (место сменилось: подвинуло новое или ушло то, что ближе к углу).
            float now = GameTime * DAY_TICKS;
            float dy = float(rgb.g - 128);
            float shown = 1.0;
            if (mode == MODE_TIMER) {
                dy = TOAST_BAR_Y;
                int timing = (rgb.r << 16) | (rgb.g << 8) | rgb.b;
                float since = ticksSince(float(timing >> 9), now);
                float duration = float((timing & 511) * 2);
                shown = clamp(since / TOAST_MOTION_TICKS, 0.0, 1.0)
                        * (1.0 - clamp((since - duration + TOAST_MOTION_TICKS) / TOAST_MOTION_TICKS, 0.0, 1.0));
            } else if (rgb.g < 128) {
                dy = TOAST_DY[rgb.g & 3];
                float since = mod(now - float((rgb.g >> 3) & 15), 16.0);
                float done = since >= TOAST_MOTION_EARLY ? 0.0 : clamp(since / TOAST_MOTION_TICKS, 0.0, 1.0);
                shown = ((rgb.g >> 2) & 1) == 1 ? 1.0 - done : done;
            } else if (rgb.g >= TOAST_MOVE_FIRST && rgb.g < TOAST_MOVE_FIRST + 112) {
                int code = rgb.g - TOAST_MOVE_FIRST;
                float from = code >= 56 ? 1.0 : -1.0;
                code = code % 56;
                dy = TOAST_DY[code / 14];
                float since = mod(now - float(code % 14), 14.0);
                float done = since >= TOAST_MOVE_EARLY ? 0.0 : clamp(since / TOAST_MOTION_TICKS, 0.0, 1.0);
                slot += from * (1.0 - toastEase(done));
            }
            float step = TOAST_HEIGHT + TOAST_GAP;
            vec2 corner = vec2(
                anchor.x < 0.25 ? TOAST_MARGIN : anchor.x > 0.75 ? -(TOAST_WIDTH + TOAST_MARGIN) : -TOAST_WIDTH * 0.5,
                anchor.y < 0.25 ? TOAST_MARGIN + slot * step
                    : anchor.y > 0.75 ? -(TOAST_HEIGHT + TOAST_MARGIN) - slot * step
                    : -TOAST_HEIGHT * 0.5 + slot * step);
            vec2 local = vec2(pos.x - origin.x - float(band) * HUD_X_STEP, pos.y - origin.y + dy) + corner;
            pos.xy = anchor * screen + local * scale;
            // Сдвиг от угла — в пикселях экрана, после масштаба: к центру, у нижних углов вверх.
            pos.y += anchor.y > 0.75 ? -shift : shift;
            // Влёт и вылет: из-за края экрана со стороны угла, с плавным разгоном и прозрачностью.
            float eased = toastEase(shown);
            float hide = (TOAST_WIDTH + TOAST_MARGIN) * scale + TOAST_HIDE_EXTRA;
            pos.x += (anchor.x < 0.5 ? -hide : hide) * (1.0 - eased);
            hudLocal = cornerOf();
            if (mode == MODE_TIMER) {
                int bits = (rgb.r << 16) | (rgb.g << 8) | rgb.b;
                hudMode = MODE_TIMER;
                hudData = vec4(float(bits >> 9), float((bits & 511) * 2), 0.0, 0.0);
                vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
            } else if (mode == MODE_PANEL) {
                hudMode = MODE_PANEL;
                vertexColor = panelColor((rgb.r << 8) | rgb.b) * vec4(1.0, 1.0, 1.0, Color.a);
            } else if (mode == MODE_IMAGE) {
                hudMode = MODE_IMAGE;
                vertexColor = vec4(rgb565((rgb.r << 8) | rgb.b), Color.a);
            } else if (mode == MODE_FILL) {
                // Полоса таймера, пока уведомление едет по стопке.
                hudMode = MODE_FILL;
                hudData = vec4(float(rgb.r) / 255.0, float(rgb.b), 0.0, 0.0);
                vertexColor = vec4(rgb.b == 0 ? vec3(1.0) : rgb332(rgb.b), Color.a);
            }
            vertexColor.a *= eased;
        } else if (mode == MODE_TIMER) {
            int bits = (rgb.r << 16) | (rgb.g << 8) | rgb.b;
            hudMode = MODE_TIMER;
            hudData = vec4(float(bits >> 9), float((bits & 511) * 2), 0.0, 0.0);
            hudLocal = cornerOf();
            vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
        } else if (mode == MODE_SPIN) {
            hudMode = MODE_SPIN;
            hudData = vec4(float(rgb.r), 0.0, 0.0, 0.0);
            hudLocal = cornerOf();
            vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
        } else if (band - 1 >= SIDEBAR_FLAG || isSidebarFar(pos, screen)) {
            // Сайдбар: строки начинаются у правого края, полосу шейдер считает от него.
            if (mode == MODE_PANEL) {
                pos.y += float(rgb.g - 128);
                vertexColor = panelColor((rgb.r << 8) | rgb.b) * vec4(1.0, 1.0, 1.0, Color.a);
            }
            sidebarElement(pos, vertexColor, screen);
        } else if (band >= 1 || hudFar) {
            int settings = band - 1;
            vec2 local = vec2(pos.x - origin.x - float(band) * HUD_X_STEP, pos.y - origin.y + float(rgb.g - 128));
            if (hudFar) {
                // Дальняя полоса: x — от кода, к y — грубый сдвиг (include/astrum_hud.glsl).
                float far = origin.x - pos.x - HUD_FAR;
                settings = int(floor(far / HUD_FAR_STEP + 0.5));
                float anchorX = ANCHORS[settings & 7].x;
                float bias = anchorX < 0.25 ? -HUD_FAR_BIAS : anchorX > 0.75 ? HUD_FAR_BIAS : 0.0;
                local.x = float(settings) * HUD_FAR_STEP - far - bias;
                local.y += float(((settings >> 9) & 15) - 8) * HUD_FAR_Y_STEP;
            }
            float scale = SCALES[(settings >> 3) & 7];
            float opacity = OPACITIES[(settings >> 6) & 7];
            pos.xy = ANCHORS[settings & 7] * screen + local * scale;
            hudLocal = cornerOf();

            if (mode == MODE_FILL) {
                hudMode = MODE_FILL;
                hudData = vec4(float(rgb.r) / 255.0, float(rgb.b), 0.0, 0.0);
                vertexColor = vec4(rgb.b == 0 ? vec3(1.0) : rgb332(rgb.b), Color.a * opacity);
            } else if (mode == MODE_ROTATE) {
                hudMode = MODE_ROTATE;
                hudData = vec4(float(rgb.r) / 256.0, 0.0, 0.0, 0.0);
                vertexColor = vec4(rgb332(rgb.b), Color.a * opacity);
            } else if (mode == MODE_IMAGE) {
                hudMode = MODE_IMAGE;
                vertexColor = vec4(rgb565((rgb.r << 8) | rgb.b), Color.a * opacity);
            } else if (mode == MODE_PANEL) {
                hudMode = MODE_PANEL;
                vertexColor = panelColor((rgb.r << 8) | rgb.b) * vec4(1.0, 1.0, 1.0, Color.a * opacity);
            } else if (head) {
                hudMode = MODE_HEAD;
                vertexColor = vec4(1.0, 1.0, 1.0, Color.a * opacity);
            }
        } else if (mode == MODE_IMAGE || mode == MODE_PANEL || mode == MODE_FILL) {
            // На своём месте (меню, диалоги, чат): цвет и сдвиг по y — как у HUD, без угла и размера.
            pos.y += float(rgb.g - 128);
            hudLocal = cornerOf();
            if (mode == MODE_FILL) {
                hudMode = MODE_FILL;
                hudData = vec4(float(rgb.r) / 255.0, float(rgb.b), 0.0, 0.0);
                vertexColor = vec4(rgb.b == 0 ? vec3(1.0) : rgb332(rgb.b), Color.a);
            } else if (mode == MODE_PANEL) {
                hudMode = MODE_PANEL;
                vertexColor = panelColor((rgb.r << 8) | rgb.b) * vec4(1.0, 1.0, 1.0, Color.a);
            } else {
                hudMode = MODE_IMAGE;
                vertexColor = vec4(rgb565((rgb.r << 8) | rgb.b), Color.a);
            }
        }
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
}
